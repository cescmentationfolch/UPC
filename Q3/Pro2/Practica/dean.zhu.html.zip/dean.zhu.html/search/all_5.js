var searchData=
[
  ['guardar_5foperacio',['guardar_operacio',['../classoperacio.html#aa1f42a80cc416ff33caea9898fe3c9b9',1,'operacio']]],
  ['guardar_5fvariable',['guardar_variable',['../classvariable.html#ac8e2c3022d51e243b4c336c023300d28',1,'variable']]]
];
