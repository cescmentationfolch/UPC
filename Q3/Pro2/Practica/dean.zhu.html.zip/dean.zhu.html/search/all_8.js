var searchData=
[
  ['pràctica_20programació_202_3a_20calculadora_20d’expressions_20aritmètiques',['Pràctica Programació 2: Calculadora d’expressions aritmètiques',['../index.html',1,'']]],
  ['print',['print',['../classresultat.html#adaa9aa55a0a9891a24f7dc04c4c1ebf2',1,'resultat']]]
];
