var searchData=
[
  ['c_5fresultat',['c_resultat',['../classresultat.html#ada9590460dcd2d077f48bc3e10ec529e',1,'resultat']]],
  ['consultar_5fvar',['consultar_var',['../classvariable.html#a0b8c6b4971c4f88aa6554e72a76b23fc',1,'variable']]]
];
