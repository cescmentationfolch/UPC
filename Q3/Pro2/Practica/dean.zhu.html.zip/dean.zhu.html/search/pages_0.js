var searchData=
[
  ['pràctica_20programació_202_3a_20calculadora_20d’expressions_20aritmètiques',['Pràctica Programació 2: Calculadora d’expressions aritmètiques',['../index.html',1,'']]]
];
