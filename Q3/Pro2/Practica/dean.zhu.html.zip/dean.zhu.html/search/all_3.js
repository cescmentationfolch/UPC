var searchData=
[
  ['entrada',['entrada',['../classresultat__lectura.html#a2b6b1c0d200ea75619f7ad50600551c6',1,'resultat_lectura']]],
  ['es_5fbool',['es_bool',['../classresultat.html#a3ed548d73663ca956ac2f087c400abe6',1,'resultat']]],
  ['es_5fdef_5fop',['es_def_op',['../classresultat__lectura.html#ac1f77e1379c99557c3bfdf2d627594f0',1,'resultat_lectura']]],
  ['es_5fdef_5fvar',['es_def_var',['../classresultat__lectura.html#a4c84ef4ddea623e7a680c639c084d11d',1,'resultat_lectura']]],
  ['es_5fenter',['es_enter',['../classresultat.html#a6d111168a77585236466639eb058a1bf',1,'resultat']]],
  ['es_5fexpressio',['es_expressio',['../classresultat__lectura.html#a0e73a239ad6dd63b591105a5553bef6f',1,'resultat_lectura']]],
  ['es_5findefinit',['es_indefinit',['../classresultat.html#a82069f4c30872bf0129366d4d998a788',1,'resultat']]],
  ['es_5fllista',['es_llista',['../classresultat.html#a38e2b83a0bac16445b80e553321d1a61',1,'resultat']]]
];
