var searchData=
[
  ['avaluar',['avaluar',['../main_8cc.html#a8618a4d38a75efdcc6be493e3b42907f',1,'main.cc']]]
];
