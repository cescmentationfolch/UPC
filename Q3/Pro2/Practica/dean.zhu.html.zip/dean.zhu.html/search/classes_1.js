var searchData=
[
  ['resultat',['resultat',['../classresultat.html',1,'']]],
  ['resultat_5flectura',['resultat_lectura',['../classresultat__lectura.html',1,'']]]
];
