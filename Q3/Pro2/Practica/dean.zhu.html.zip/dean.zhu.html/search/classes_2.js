var searchData=
[
  ['variable',['variable',['../classvariable.html',1,'']]]
];
