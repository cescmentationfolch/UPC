var searchData=
[
  ['operacio',['operacio',['../classoperacio.html',1,'']]]
];
