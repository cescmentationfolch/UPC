var searchData=
[
  ['resultat',['resultat',['../classresultat.html#a536c47bd86857e3f5bfb26e156cb1877',1,'resultat']]],
  ['resultat_5flectura',['resultat_lectura',['../classresultat__lectura.html#a73ef39653019fabadde9454451121b3f',1,'resultat_lectura']]]
];
