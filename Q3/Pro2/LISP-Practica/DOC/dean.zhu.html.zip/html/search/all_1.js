var searchData=
[
  ['buscar',['buscar',['../classvariable.html#a1d4aa21d6874589f26ec2e7bf08d3e67',1,'variable']]]
];
