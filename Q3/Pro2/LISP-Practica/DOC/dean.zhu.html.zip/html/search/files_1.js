var searchData=
[
  ['operacio_2ehh',['operacio.hh',['../operacio_8hh.html',1,'']]]
];
