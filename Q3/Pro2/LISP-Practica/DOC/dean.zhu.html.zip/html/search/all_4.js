var searchData=
[
  ['fi_5fentrada',['fi_entrada',['../classresultat__lectura.html#a178d0aae65fbce754ec5d99a04732bf0',1,'resultat_lectura']]]
];
