var searchData=
[
  ['resultat_2ehh',['resultat.hh',['../resultat_8hh.html',1,'']]],
  ['resultat_5flectura_2ehh',['resultat_lectura.hh',['../resultat__lectura_8hh.html',1,'']]]
];
