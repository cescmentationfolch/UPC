var searchData=
[
  ['operacio',['operacio',['../classoperacio.html#aa16956dfb69552de3ff43261de600bbe',1,'operacio']]],
  ['operar',['operar',['../classoperacio.html#ab64cf3a9e19efd65c2ea3fe276cfabaf',1,'operacio']]]
];
