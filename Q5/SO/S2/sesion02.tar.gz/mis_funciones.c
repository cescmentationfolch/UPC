#include <stdio.h>
#include <string.h>

const int MAX_SIZE = 8;

unsigned int char2int(char c) {
  return c - '0';
}

int mi_atoi(char *s) {
  int ans = 0;
  for(int i = (s[0] == '-'); s[i]; ++i) {
    ans *= 10;
    ans += char2int(s[i]);
  }
  if(s[0] == '-') ans *= -1;
  return ans;
}
int esNumero(char *str) {
  if(str == NULL || strlen(str) > MAX_SIZE + (str[0] == '-')) return 0;
  for(int i = (str[0] == '-') ; str[i] != '\0'; ++i) {
    if(str[i] < '0' || str[i] > '9') return 0;
  }
  return 1;
}
