#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
  int palabras = 0;
  char buf[60];
  int last = 1;
  for(int i = 0; argv[1][i]; ++i) {
    if(last && (argv[1][i] != ' ' && argv[1][i] != '.' && argv[1][i] != ',' && argv[1][i] != '\n')) {
      ++palabras;
      last = 0;
    }
    if(argv[1][i] == ' ' || argv[1][i] == '.' || argv[1][i] == ',' || argv[1][i] == '\n') last = 1;
  }
  sprintf(buf, "%d palabra(s)\n", palabras);
  write(1, buf, strlen(buf));

}
