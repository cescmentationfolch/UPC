#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
  int fd = open("./myPipe", O_RDONLY);
  char buf[1024];
  int p;
  while((p = read(fd, buf, sizeof(buf))) > 0) {
    buf[p] = '\0';
    write(1, buf, strlen(buf));
  }
  close(fd);
}
