#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAXSTRING 256

int main(int argc, char *argv[]) {
  int socketFD;
  int connectionFD;
  int ret;

  socketFD = createSocket ("./mySocket");
  if (socketFD < 0)
    {
      perror ("Error creating socket\n");
      exit (1);
    }

  connectionFD = serverConnection (socketFD);
  if (connectionFD < 0)
    {
      perror ("Error establishing connection \n");
      exit (1);
    }

  char buf[1024];
  int p;
  while((p = read(connectionFD, buf, sizeof(buf))) > 0) {
    buf[p] = '\0';
    write(1, buf, strlen(buf));
  }
  closeConnection (connectionFD);
  deleteSocket (socketFD, "./mySocket");
}
