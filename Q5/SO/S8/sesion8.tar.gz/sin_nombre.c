#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
  int pipefd[2];
  pipe(pipefd);
  int pid = fork();
  char *buf1 = "Inicio\n";
  char *buf2 = "Fin\n";
  if(pid == 0) {
    close(pipefd[1]);
    dup2(pipefd[0], 0);
    execlp("cat", "cat", (char *)NULL);
  }
  else {
    close(pipefd[0]);
    write(pipefd[1], buf1, strlen(buf1));
    //close(pipefd[1]);
    waitpid(pid, NULL, 0);
    write(1, buf2, strlen(buf2));

  }

}
