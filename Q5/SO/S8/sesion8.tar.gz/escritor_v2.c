#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

int main(int argc, char *argv[]) {
  int fd = open("./myPipe", O_WRONLY | O_NONBLOCK);
  if(errno == ENXIO) {
    char *buf = "No process is reading the pipe\n";
    write(1, buf, strlen(buf));
    while(errno == ENXIO) fd = open("./myPipe", O_WRONLY);
  }
  char *start = "There is a process reading the pipe\n";
  write(1, start, strlen(start));
  char buf[1024];
  int p = 1;
  while((p = read(0, buf, sizeof(buf))) > 0) {
    buf[p] = '\0';
    write(fd, buf, strlen(buf));
  }
  close(fd);
}
