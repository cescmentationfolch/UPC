#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <errno.h>

void handler(int s) {
  char *buf = "Received Signal\n";
  write(1, buf, strlen(buf));
}
main(){
	char c;
	struct sigaction sa;
	sigset_t mask;
	sa.sa_handler = &handler;
       	sa.sa_flags = SA_RESTART;
	sigfillset(&sa.sa_mask);
	sigfillset(&mask);
	sigdelset(&mask, SIGINT);
	sigprocmask(SIG_BLOCK, &mask, NULL);
	sigaction(SIGINT, &sa, NULL);
	
	int ret = read(0, &c, sizeof(char));
	char *err1 = "Successful read\n";
	char *err2 = "Read with error\n";
	char *err3 = "Read interrupted by a signal\n";
	if(ret > 0) write(1 , err1, strlen(err1));
	if(ret == -1) {
	  if(errno == EINTR) write(1, err3, strlen(err3));
	  else write(1, err2, strlen(err2));
	}
	write(1, &c, sizeof(char));

}
