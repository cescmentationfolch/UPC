#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

int main() {
    char buffer[1024];
    int fd = open("./file", O_RDWR);
    int x = read(fd, buffer, sizeof(buffer));
    //despues de leer nos encontramos al final del fichero
    write(fd, buffer, x);
}
