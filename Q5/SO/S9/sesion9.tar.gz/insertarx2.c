#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

int Usage() {
    char* buf = "el ejecutable toma como parametro el fichero i la posicion a la cual insertar una X indexado a 0\n";
    write(1, buf, strlen(buf));
    return 1;
}

const int MAX_SIZE = 8;
unsigned int char2int(char c) {
  return c - '0';
}

int mi_atoi(char *s) {
  int ans = 0;
  for(int i = (s[0] == '-'); s[i]; ++i) {
    ans *= 10;
    ans += char2int(s[i]);
  }
  if(s[0] == '-') ans *= -1;
  return ans;
}
int esNumero(char *str) {
  if(str == NULL || strlen(str) > MAX_SIZE + (str[0] == '-')) return 0;
  for(int i = (str[0] == '-') ; str[i] != '\0'; ++i) {
    if(str[i] < '0' || str[i] > '9') return 0;
  }
  return 1;
}


int main(int argc, char* argv[]) {
    if(argc != 3 || !esNumero(argv[2])) return Usage();
    int pos = mi_atoi(argv[2]);
    char buffer[1024];
    int fd = open(argv[1], O_RDWR);
    int x = read(fd, buffer, sizeof(buffer));
    if(pos >= x) {
        char* er = "La posicion especificada no existe\n";
        write(1, er, strlen(er));
        return 1;
    }
    char print[1024];
    int it = 0;
    write(1, buffer, x);
    for(int i = 0; i < x; ++i, ++it) {
        if(i == pos)print[it++] = 'X';
        print[it] = buffer[i];
    }
    lseek(fd, 0, SEEK_SET);
    write(fd, print, x + 1);
}
