#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

int Usage() {
    char* buf = "el ejecutable toma como unico parametro el fichero a invertir\n";
    write(1, buf, strlen(buf));
    return 1;
}
int main(int argc, char* argv[]) {
    if(argc != 2) return Usage();
    char buffer[1024];
    int fd1 = open(argv[1], O_RDONLY);
    char file[80];
    strcpy(file, argv[1]);
    strcat(file, ".inv");
    int fd2 = creat(file, S_IRUSR | S_IWUSR);
    int x = read(fd1, buffer, sizeof(buffer));
    for(int i = 0; i < (x >> 1); ++i) {
        char aux = buffer[i];
        buffer[i] = buffer[x-i-1];
        buffer[x-i-1] = aux;
    }
    write(fd2, buffer, x);
}
