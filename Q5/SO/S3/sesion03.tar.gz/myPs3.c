#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void error_y_exit(char *msg,int exit_status)
{
  perror(msg);
  exit(exit_status);
}

void muta_a_ps(char *username) {
  execlp("ps", "ps", "-u", username, (char*)NULL);
  error_y_exit("Ha fallado al mutacion a ps", 1);
}

int main(int argc, char *argv[]) {
  if(argc < 2) error_y_exit("no hay suficientes argumentos", 1);
      char buffer[80];
  sprintf(buffer, "Mi PID: %d\n", getpid());
  write(1, buffer, strlen(buffer));
  for(int i = 1; i < argc; ++i) {
    int pid = fork();
    if(!pid) {
      sprintf(buffer, "Mi PID: %d, Mi parametro %s\n", getpid(),argv[i]);
      write(1, buffer, strlen(buffer));
      muta_a_ps(argv[i]);
    }
  }
  while(waitpid(-1, NULL, 0) > 0);
  char c;
  read(1,&c,sizeof(char));
}
