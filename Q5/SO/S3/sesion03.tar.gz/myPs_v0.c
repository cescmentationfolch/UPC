#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

void error_y_exit(char *msg,int exit_status)
{
  perror(msg);
  exit(exit_status);
}

int main(int argc, char *argv[]) {
  if(argc < 2) error_y_exit("no hay suficientes argumentos", 1);
  int pid = fork();
  char buffer[80];
  if(!pid) {
    sprintf(buffer, "Mi PID: %d, Mi parametro %s\n", getpid(), argv[1]);
  }
  else {
    sprintf(buffer, "Mi PID: %d\n", getpid());
  }
  write(1, buffer, strlen(buffer));
  while(1){}
}
