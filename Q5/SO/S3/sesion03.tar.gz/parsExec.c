#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void error_y_exit(char *msg,int exit_status)
{
  perror(msg);
  exit(exit_status);
}

void muta_a_listaparametros() {
  int r = rand() % 4;
  if(r == 0) execlp("./listaparametros", "listaparametros", "124314" , "fasj", "hola", NULL);
  if(r == 1) execlp("./listaparametros", "listaparametros", NULL);
  
  if(r == 2) execlp("./listaparametros", "listaparametros", "hola", NULL);

  if(r == 3) execlp("./listaparametros", "listaparametros", "a", "b", "c", NULL);

  error_y_exit("el proceso no ha mutado corretamente", 1);
}

int main(int argc, char *argv[]) {
  for(int i = 1; i < 4; ++i) {
    int pid = fork();
    if(!pid) {
      muta_a_listaparametros();
    }
  }
  while(waitpid(-1, NULL, 0) > 0);
}
