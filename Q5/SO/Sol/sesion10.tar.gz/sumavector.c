#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>

#define MAX 10000

#define NTHREADS 10

int globalvector[MAX];

pthread_mutex_t stop;

struct infojob {
	int ini;	/* posición inicial */
	int fin;	/* posición final */
	int res;	/* resultado parcial */
};

struct infojob	jobs[NTHREADS];

void *sum_vector(void* y) {
	struct infojob www = *((struct infojob*)(y));
	int a =	www.ini;
	int b = www.fin;
	int u = a/(MAX/NTHREADS);
	int var = 0;
	while(a<b) {
		var += globalvector[a];
		++a;
	}
	jobs[u].res = var;
	
}

void main()
{
	pthread_mutex_init (&stop,NULL);
	int res;
	int i;
	int suma;
	char buf[100];
	for (i=0; i<MAX; i++) {
		globalvector[i] = i;
	}	
	pthread_t thread[NTHREADS];
	int b;
	int div = (MAX/NTHREADS);
	for(b=0; b<NTHREADS; ++b) {
		jobs[b].ini = b*div;
		jobs[b].fin = b*div+div-1;

		if(( res = pthread_create(&thread[b],NULL,sum_vector,&jobs[b]))!=0){
			perror("pthread create");
			exit(1);
		}
	}	
	int j;
	int total = 0;
	for(j=0; j<NTHREADS; ++j) {
		if((res=pthread_join(thread[j],NULL))!=0){ 
			perror("Error joining:");
			exit(1);
		}
		
		total += jobs[j].res;
	}	
	sprintf (buf, "El resultado de la suma es %d\n", total);
	write (1, buf, strlen(buf));
}
