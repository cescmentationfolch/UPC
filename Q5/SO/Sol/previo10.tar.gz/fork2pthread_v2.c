#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include <pthread.h>

void mensaje() {
	char buffer[80];
	sprintf(buffer,"HIJO: Soy el thread %lu\n", pthread_self());
	write(1, buffer, strlen(buffer));
	pthread_exit(0);
}

int main(int argc,char *argv[])
{
	char buffer[80];

	sprintf(buffer,"Antes del fork: Soy el proceso %d\n",getpid());
	write (1, buffer, strlen(buffer));

	pthread_t thread1;
	if(pthread_create(&thread1, NULL, (void *) &mensaje, (void *) NULL)!=0) { 
		// retorna 0 si no hay error en la creación del thread
		sprintf(buffer,"Se ha producido un error\n");
		write(1, buffer, strlen(buffer));
	}

	sprintf(buffer,"PADRE: Soy el proceso %d\n",getpid());
	write(1, buffer, strlen(buffer));

	sprintf(buffer,"Solo lo ejecuta el padre: Soy el proceso %d\n",getpid());
	write(1, buffer, strlen(buffer));

	pthread_join(thread1, 0); // no avanzamos hasta que hayamos recibido el exit status del thread

	return 0;
}
