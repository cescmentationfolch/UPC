#include <signal.h>
#include <stdio.h>
#include <string.h>

int tiempo = 0;

void trata(int s) {
	if(s==14) {
		// Alarma
		tiempo+=1;
		alarm(1);
	}else if(s==10) {
		// SIGUSR1
		tiempo=0;
		alarm(1);
	}else if(s==12) {
		// SIGUSR2+
		char buff[80];
		sprintf(buff,"Segundos: %d\n",tiempo);
		write(1,buff,strlen(buff));
		alarm(1);
	}
}

int main() {
	signal(SIGALRM, trata);
	signal(SIGUSR1, trata);
	signal(SIGUSR2, trata);
	alarm(1);
	pause();
	//while(1);
}
