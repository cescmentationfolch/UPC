#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>


/* ESTA VARIABLE SE ACCEDE DESDE LA FUNCION DE ATENCION AL SIGNAL Y DESDE EL MAIN */
int segundos=0;
/* FUNCION DE ATENCION AL SIGNAL SIGALRM */
void funcion_alarma(int s)
{
	if(s==14) {
	// SIGALRM
		segundos=segundos+10;
	}else if(s==10){
	// SIGUSR1
		char buff[256];
		sprintf(buff, "Se ha recibido SIGUSR1\n");
		write(1, buff, strlen(buff)); 
	}
}
int main (int argc,char * argv[])
{
	if(fork()==0) {
	/* REPROGRAMAMOS EL SIGNAL SIGALRM */
		signal(SIGALRM,funcion_alarma);
	}
	signal(SIGUSR1,funcion_alarma);
	while (segundos<100)
	{
		alarm(90); 	/* Programamos la alarma para dentro de 10 segundos */
		pause(); // modificación para pregunta 30
		execlp("find","find","/", '\0', NULL, NULL);
		pause();  	/* Nos bloqueamos a esperar que nos llegue un evento */
	}
	exit(1);
}
