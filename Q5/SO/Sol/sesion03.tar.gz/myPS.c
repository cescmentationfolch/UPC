#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

void error_y_exit(char *msg,int exit_status) {
	perror(msg);
	exit(exit_status);
}

void muta_a_PS(char *username) {
	execlp("ps", "ps", "-u", username, (char*)NULL);
	error_y_exit("Ha fallado la mutación al ps", 1);
}

int main(int argc,char *argv[]) {
	int a = fork();
	//while(1);
	char buffer[80];
	switch(a) {
		case 0: /* Hijo */
			sprintf(buffer,"%d %s\n",getpid(),argv[1]);
			write(1,buffer,strlen(buffer));
			muta_a_PS(argv[1]);
			while(1);
		break;
		case -1:
			// Error
			error_y_exit("Error en fork",1);
		break;
		default: /* Padre */
			sprintf(buffer,"%d\n",getpid());
			write(1,buffer,strlen(buffer));
			while(1);
		break;
	}	
}
