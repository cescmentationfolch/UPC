#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

/*void error_y_exit (char *msg, int exit_status)
{
  perror (msg);
  exit (exit_status);
}*/

int main (int argc, char *argv[]) {
	int i;
	char buffer[256];
	for(i=1;i<=10;++i) {
		int a = fork();
		if(a==0) {
			sprintf(buffer,"%d",i);
			execlp("expr", "expr", argv[1], "*",  buffer, (char*)NULL);
			//error_y_exit ("Error en fork", 1);
		}else if(a==-1) {
		
		}else{
		//char c ='a';
		//read (1, &c, sizeof (char));
		wait(0);
		}
	}
}
