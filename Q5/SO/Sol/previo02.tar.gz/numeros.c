#include <stdio.h>
#include <string.h>

#define MAX_SIZE 8

int
esNumero (char *str)
{
  int numeros = 0;
  if (str != NULL)
    {
      int i = 0;
      numeros = 1;
      while (str[i] != '\0' && numeros == 1)
	{
	  if ((str[i] < '0' || str[i] > '9') && !(i == 0 && str[i] == '-'))
	    numeros = 0;
	  ++i;
	  if (i > MAX_SIZE)
	    numeros = 0;
	}
    }
  return numeros;
}

void
main (int argc, char *argv[])
{
  int i;
  for (i = 1; i < argc; ++i)	// i=1, pues no nos interesa evaluar el nombre del ejecutable (contenido en argv[0]).
    {
      char buffer[32];
      int es = esNumero (argv[i]);
      if (es == 1)
	sprintf (buffer, "El resultado es %d (es un entero)\n", es);
      else
	sprintf (buffer, "El resultado es %d (no es un entero)\n", es);
      write (1, buffer, strlen (buffer));
    }
}
