#include <unistd.h>
#include <stdio.h>
#include <string.h>

main(){
	char c[5];
	int fd;
	 
	read(0, &fd, sizeof(fd));
	sprintf(c,"%d\n",fd);
	write(1,&c,strlen(c));
}