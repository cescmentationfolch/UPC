#include "mis_funciones.h"

void
main (int argc, char *argv[])
{
  int i = 1;
  int suma = 0;
  int stop = 0;
char buffer[256];
	while(i<argc && stop==0) {
	if(esNumero(argv[i])) {
		int mi = mi_atoi(argv[i]);
      		suma=suma+mi;
	}else{
		stop=1;
		sprintf(buffer, "Error: el parámetro \"%s\" no es un número. \n", argv[i]);	
	}
	++i;
	}

	if(stop==0) {
	sprintf(buffer, "La suma es %d\n", suma);
	}

	write(1, buffer, strlen (buffer));	

}
