int esNumero (char *str);
unsigned int char2int(char c);
int power_10(int a, int b);
int mi_atoi(char *s);
