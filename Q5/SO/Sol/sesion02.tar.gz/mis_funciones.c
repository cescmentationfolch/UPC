#define MAX_SIZE 8

#include <stdio.h>
#include <string.h>

int
esNumero (char *str)
{
  int numeros = 0;
  if (str != NULL)
    {
      int i = 0;
      numeros = 1;
      while (str[i] != '\0' && numeros == 1)
	{
	  if ((str[i] < '0' || str[i] > '9') && !(i == 0 && str[i] == '-'))
	    numeros = 0;
	  ++i;
	  if (i > MAX_SIZE)
	    numeros = 0;
	}
    }
  return numeros;
}

unsigned int char2int(char c) {
  return c-'0';
}

int power_10(int a, int b) {
	int i=0;
	int c=1;
	while(i<b) {
		c=(c*10);
		++i;
	}
	return a*c;
}

int mi_atoi(char *s) {
  	int j = 0;
	int negativo = 0;
	if(s[j]=='-')
		negativo = 1;
	while (s[j] != '\0') {
		++j;	
	}
	j=j-1;

	int i=0;
	if(negativo==1) {
		i=1;	
		j=j-1;
	}
	int numeros = 1;
	int suma = 0;
	while (s[i] != '\0' && numeros == 1)
	{
	  if ((s[i] < '0' || s[i] > '9') && !(i == 0 && s[i] == '-')) {
	    	numeros = 0;
	  }else{
		int k = char2int(s[i]);
		k = power_10(k,j);
	    	suma=suma+k;
	  }
	  ++i;
	  --j;
	}
	if(negativo)
		suma=suma*-1;
		
  	return suma;
}
