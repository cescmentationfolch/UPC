#include <stdio.h>
#include <string.h>

int main(int argc,char *argv[]) {
	int i=0;
	int palabras=1;
	if(argc>1) {
	while(argv[1][i]!='\0') {
		if(argv[1][i]=='\n' || argv[1][i]==' ' || argv[1][i]=='.' || argv[1][i]==',')
			palabras=palabras+1;
		i=i+1;
	}
	char buffer[80];
	sprintf(buffer,"%d palabras\n",palabras);
	write(1,buffer,strlen(buffer));
	}
}