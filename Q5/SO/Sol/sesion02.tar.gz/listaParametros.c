#include <stdio.h>
#include <string.h>

void Usage() {
	printf("Usage: listaParametros arg1 [arg2..argn]\nEste programa escribe por su salida la lista de argumentos que recibe.\n");
}

void main(int argc,char *argv[])
{
	if(argc==1) {
		Usage();
	}else{
		int i;
		char buf[80];
		for (i=1;i<argc;i++){
		sprintf(buf,"El argumento %d es %s\n",i,argv[i]);
		write(1,buf,strlen(buf));
		}
	}
}
