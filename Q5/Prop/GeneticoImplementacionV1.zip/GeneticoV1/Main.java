//package simpleGav1;

public class Main {

  public static void main(String[] args) {
    GA ga = new GA();
    ga.algoritmoGenetico();
  }

}

