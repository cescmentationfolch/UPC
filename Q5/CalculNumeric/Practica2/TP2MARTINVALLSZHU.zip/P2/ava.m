function [ res ] = ava(x) 
    res = integra(100,x);
end

