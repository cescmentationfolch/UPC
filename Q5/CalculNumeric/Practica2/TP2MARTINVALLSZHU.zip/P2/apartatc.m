m = 100;
aproxIn = 0.8;
newton(aproxIn, integra(m,b)/2, m)
