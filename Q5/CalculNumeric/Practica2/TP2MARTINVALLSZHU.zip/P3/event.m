function [value, isterminal, direction] = event(x, y)
value = y(2);
isterminal = 1;
direction = -1;