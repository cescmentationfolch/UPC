function res = P4derivada(x)
format long;
res = 45*x^4 - 24*x^3 - 51*x^2 - 102*x + 40;
endfunction