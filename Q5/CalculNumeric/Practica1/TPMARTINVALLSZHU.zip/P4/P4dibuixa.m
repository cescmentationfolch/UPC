function P4dibuixa(l, r)
x = linspace(l, r, 250);
y = P4avalua(x);

plot(x,y)
grid on;
endfunction
