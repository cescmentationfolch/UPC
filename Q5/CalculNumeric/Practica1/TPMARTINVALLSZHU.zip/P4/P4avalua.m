function res = P4avalua(x)
format long;
res = 9*x.^5 - 6*x.^4 - 17*x.^3 - 51*x.^2 + 40*x - 7;
endfunction


