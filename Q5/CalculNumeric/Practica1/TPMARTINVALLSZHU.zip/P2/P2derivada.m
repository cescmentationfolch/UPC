function res = P2derivada(x, a1, a4, beta)
res = a1*sin(x)/a4 - sin(beta - x);
endfunction

